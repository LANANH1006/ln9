package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Bridge: tự ngồi (sneak) ở mép để không rơi; cầm block thì tự đặt block ra mép. */
public class Bridge {
    static boolean pressed;
    static int cd;

    static void release(MinecraftClient mc) {
        if (pressed) { mc.options.sneakKey.setPressed(false); pressed = false; }
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (!c.bridgeOn || !c.enabled || p == null || mc.world == null || mc.currentScreen != null || !p.isOnGround()) { release(mc); return; }
        Vec3d v = p.getVelocity();
        double sp = Math.hypot(v.x, v.z);
        if (sp < 0.02) { release(mc); return; }
        double dx = v.x / sp, dz = v.z / sp;
        BlockPos probe = BlockPos.ofFloored(p.getX() + dx * 0.4, p.getY() - 0.5, p.getZ() + dz * 0.4);
        boolean edge = mc.world.getBlockState(probe).getCollisionShape(mc.world, probe).isEmpty();
        if (!edge) { release(mc); return; }
        mc.options.sneakKey.setPressed(true); pressed = true;
        if (cd-- <= 0 && p.getMainHandStack().getItem() instanceof BlockItem bi) {
            cd = 2;
            if (!Util.placeBlockLook(probe, bi)) Util.placeBlock(probe, bi);
        }
    }
}
