package com.safeanchor;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.component.DataComponentTypes;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Danh sách module theo 7 tab + lưu/tải cài đặt + phím tắt. */
public class ModuleManager {
    public static final List<Module> ALL = new ArrayList<>();
    static final Map<String, Boolean> down = new HashMap<>();
    static final Map<String, Long> lastSig = new HashMap<>();
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("lananh-modules.json"); }
    static Config C() { return Config.I; }

    public static List<Module> of(Module.Cat c) { List<Module> l = new ArrayList<>(); for (Module m : ALL) if (m.cat == c) l.add(m); return l; }

    /** Module nối với tính năng có sẵn. */
    static Module bridge(String n, String d, Module.Cat c, BooleanSupplier g, Consumer<Boolean> s) {
        Module m = new Module(n, d, c); m.ext = g; m.extSet = s; ALL.add(m); return m;
    }
    /** Module chỉ có giao diện + cài đặt (chưa có logic). */
    static Module stub(String n, String d, Module.Cat c) { Module m = new Module(n, d, c); m.implemented = false; ALL.add(m); return m; }
    static <T extends Module> T reg(T m) { ALL.add(m); return m; }

    // nền menu (module "Giao diện")
    public static Setting.Mode bgMode; public static Setting.Color bgC1, bgC2; public static Setting.Slider bgDim, bgPanel, bgTrans;

    static final String[] CAT_ID = {"deepslate", "bricks", "cobble", "planks", "glass", "storage", "utility", "redstone", "obsidian", "rails"};
    static final String[] CAT_NAME = {"Deepslate", "Gạch", "Cobble", "Gỗ", "Kính", "Rương", "Lò/bàn", "Redstone", "Obsidian", "Ray"};

    /** Module dò căn cứ: Alpha / Min-Max Y / Tầm / Màu (+ bộ lọc block). Giá trị đồng bộ với Mods.Cfg. */
    static Module scanMod(String n, String d, String id, BooleanSupplier on, Consumer<Boolean> set, boolean yr, boolean filt, boolean two) {
        Module m = bridge(n, d, Module.Cat.RENDER, on, set);
        Mods.Cfg g = Mods.cfg(id);
        var alpha = m.<Setting.Slider>add(new Setting.Slider("Alpha", g.alpha, 5, 200, 1));
        Setting.Slider mn = null, mx = null;
        if (yr) { mn = m.<Setting.Slider>add(new Setting.Slider("Min Y", g.minY, -64, 320, 1)); mx = m.<Setting.Slider>add(new Setting.Slider("Max Y", g.maxY, -64, 320, 1)); }
        var rng = m.<Setting.Slider>add(new Setting.Slider("Tầm", g.range, 8, 128, 1));
        var col = m.<Setting.Color>add(new Setting.Color(two ? "An toàn" : "Màu", g.color));
        Setting.Color col2 = two ? m.<Setting.Color>add(new Setting.Color("Không an toàn", g.color2)) : null;
        Setting.Check[] chk = new Setting.Check[filt ? CAT_ID.length : 0];
        for (int i = 0; i < chk.length; i++) chk[i] = m.<Setting.Check>add(new Setting.Check(CAT_NAME[i], !g.off.contains(CAT_ID[i])));
        final Setting.Slider fmn = mn, fmx = mx;
        m.apply = () -> {
            g.alpha = alpha.geti(); g.range = rng.geti(); g.color = col.rgb;
            if (col2 != null) g.color2 = col2.rgb;
            if (fmn != null) { g.minY = fmn.geti(); g.maxY = fmx.geti(); }
            for (int i = 0; i < chk.length; i++) { boolean has = g.off.contains(CAT_ID[i]); if (chk[i].get() == has) { if (has) g.off.remove(CAT_ID[i]); else g.off.add(CAT_ID[i]); } }
        };
        return m;
    }

    static {
        Module.Cat CB = Module.Cat.COMBAT, MV = Module.Cat.MOVEMENT, PL = Module.Cat.PLAYER, RD = Module.Cat.RENDER, WO = Module.Cat.WORLD, MI = Module.Cat.MISC, HD = Module.Cat.HUD;

        // ================= TAB 1: COMBAT =================
        { Module m = bridge("KillAura", "Tự động đánh", CB, () -> C().autoPvp, v -> C().autoPvp = v);
          var mode = m.<Setting.Mode>add(new Setting.Mode("Mode", 0, "Single", "Switch"));
          var rng = m.<Setting.Slider>add(new Setting.Slider("Range", C().pvpRange, 2, 6, 0.1));
          var smooth = m.<Setting.Slider>add(new Setting.Slider("Speed (smooth)", C().pvpSmooth, 0.05, 1, 0.05));
          var rot = m.<Setting.Check>add(new Setting.Check("Rotate", true));
          var crystal = m.<Setting.Check>add(new Setting.Check("Dùng crystal", C().pvpCrystal));
          var walk = m.<Setting.Check>add(new Setting.Check("Tự đi tới", C().pvpWalk));
          m.apply = () -> { C().pvpRange = rng.get(); C().pvpSmooth = smooth.get(); C().pvpCrystal = crystal.get(); C().pvpWalk = walk.get(); C().pvpSilent = !rot.get(); }; }

        { Module m = bridge("CrystalAura", "Tự động nổ crystal", CB, () -> C().crystal, v -> C().crystal = v);
          var rng = m.<Setting.Slider>add(new Setting.Slider("Range", C().crystalRange, 2, 6, 0.1));
          var delay = m.<Setting.Slider>add(new Setting.Slider("Delay (tick)", C().crystalDelay, 0, 10, 1));
          var self = m.<Setting.Slider>add(new Setting.Slider("Max self damage", C().maxSelfDamage, 1, 20, 0.5));
          var obs = m.<Setting.Check>add(new Setting.Check("Tự đặt obsidian", C().crystalAutoObs));
          var pearl = m.<Setting.Check>add(new Setting.Check("Crystal khi pearl", C().pearlCrystal));
          m.apply = () -> { C().crystalRange = rng.get(); C().crystalDelay = delay.geti(); C().maxSelfDamage = self.get(); C().crystalAutoObs = obs.get(); C().pearlCrystal = pearl.get(); }; }

        { Module m = bridge("AutoTotem", "Tự đổi/cầm totem", CB, () -> C().autoTotem, v -> C().autoTotem = v);
          var slot = m.<Setting.Slider>add(new Setting.Slider("Ô totem (hotbar)", C().totemSlot, 1, 9, 1));
          var spare = m.<Setting.Slider>add(new Setting.Slider("Ô tạm", C().spareSlot, 1, 9, 1));
          m.apply = () -> { C().totemSlot = slot.geti(); C().spareSlot = spare.geti(); }; }

        { Module m = bridge("AnchorAura", "Combo Anchor (Nether/End)", CB, () -> C().anchor, v -> C().anchor = v);
          var safe = m.<Setting.Check>add(new Setting.Check("Safe (chắn trước khi nổ)", C().anchorSafe));
          var shield = m.<Setting.Check>add(new Setting.Check("Anchor Shield", C().anchorShield));
          m.apply = () -> { C().anchorSafe = safe.get(); C().anchorShield = shield.get(); }; }

        { Module m = bridge("BedAura", "Đánh bằng giường", CB, () -> false, v -> {});
          m.implemented = false; m.add(new Setting.Slider("Range", 4.5, 2, 6, 0.1)); m.add(new Setting.Slider("Delay", 2, 0, 10, 1)); }

        { Module m = bridge("Criticals", "Tạo đòn chí mạng", CB, () -> C().hitSelect, v -> C().hitSelect = v);
          var min = m.<Setting.Slider>add(new Setting.Slider("Min cooldown %", C().hitSelectMin, 50, 100, 1));
          m.apply = () -> C().hitSelectMin = min.geti(); }

        { Module m = bridge("Triggerbot", "Tự đánh khi ngắm trúng", CB, () -> C().trigOn, v -> C().trigOn = v); }
        { Module m = bridge("Velocity", "Giảm knockback", CB, () -> C().velOn, v -> C().velOn = v);
          var h = m.<Setting.Slider>add(new Setting.Slider("Horizontal %", C().velH, 0, 100, 1));
          var vv = m.<Setting.Slider>add(new Setting.Slider("Vertical %", C().velV, 0, 100, 1));
          m.apply = () -> { C().velH = h.geti(); C().velV = vv.geti(); }; }

        { Module m = bridge("ElytraMace", "Bay elytra đập mace", CB, () -> C().autoMace, v -> { if (v != C().autoMace) ElytraMace.toggle(MinecraftClient.getInstance()); });
          m.preview = 1;
          var style = m.<Setting.Mode>add(new Setting.Mode("Kiểu", C().maceStyle, "Thả rơi", "Lao pháo"));
          var view = m.<Setting.Mode>add(new Setting.Mode("Góc nhìn", C().maceView, "Giữ", "1st", "3rd sau", "3rd trước"));
          var lock = m.<Setting.Check>add(new Setting.Check("Khóa 1 mục tiêu", C().maceLock));
          var search = m.<Setting.Check>add(new Setting.Check("Bay tìm", C().maceSearch));
          var chase = m.<Setting.Check>add(new Setting.Check("Đuổi", C().maceChase));
          var rocket = m.<Setting.Check>add(new Setting.Check("Pháo", C().maceUseRocket));
          var swapC = m.<Setting.Check>add(new Setting.Check("Đổi áo", C().maceSwapChest));
          var auto = m.<Setting.Check>add(new Setting.Check("Tự đánh", C().maceAutoHit));
          var axe = m.<Setting.Check>add(new Setting.Check("Rìu phá khiên", C().maceAxe));
          var chain = m.<Setting.Check>add(new Setting.Check("Chuỗi đập", C().maceChain));
          var ball = m.<Setting.Check>add(new Setting.Check("Thả thẳng", C().maceBallistic));
          var head = m.<Setting.Check>add(new Setting.Check("Đạp đầu", C().headHit));
          var rng = m.<Setting.Slider>add(new Setting.Slider("Tầm", C().maceRange, 16, 300, 1));
          var searchSec = m.<Setting.Slider>add(new Setting.Slider("Tìm (giây)", C().maceSearchSec, 10, 180, 1));
          var dive = m.<Setting.Slider>add(new Setting.Slider("Cao ≥", C().maceDiveDist, 6, 60, 1));
          var hz = m.<Setting.Slider>add(new Setting.Slider("Lệch ≤", C().maceHorizDive, 4, 40, 1));
          var swap = m.<Setting.Slider>add(new Setting.Slider("Đổi áo cách", C().maceSwapDist, 6, 40, 1));
          var hit = m.<Setting.Slider>add(new Setting.Slider("Đánh ≤", C().maceHitDist, 1, 6, 0.1));
          var abort = m.<Setting.Slider>add(new Setting.Slider("Bay lại khi lệch", C().maceAbortDist, 4, 30, 1));
          var hp = m.<Setting.Slider>add(new Setting.Slider("Máu ≥", C().minSelfHealth, 0, 20, 1));
          var chainSw = m.<Setting.Slider>add(new Setting.Slider("Chuỗi: đổi áo", C().maceChainSwap, 2, 10, 0.5));
          var err = m.<Setting.Slider>add(new Setting.Slider("Sai số thả", C().maceDropErr, 0.5, 4, 0.1));
          var hTol = m.<Setting.Slider>add(new Setting.Slider("Đạp: cao", C().headHitTol, 0, 2, 0.1));
          var hHz = m.<Setting.Slider>add(new Setting.Slider("Đạp: ngang", C().headHitHoriz, 0.5, 3, 0.1));
          m.apply = () -> { C().maceStyle = style.index; C().maceView = view.index; C().maceLock = lock.get(); C().maceSearch = search.get(); C().maceChase = chase.get();
              C().maceUseRocket = rocket.get(); C().maceSwapChest = swapC.get(); C().maceAutoHit = auto.get(); C().maceAxe = axe.get(); C().maceChain = chain.get();
              C().maceBallistic = ball.get(); C().headHit = head.get(); C().maceRange = rng.get(); C().maceSearchSec = searchSec.geti(); C().maceDiveDist = dive.get();
              C().maceHorizDive = hz.get(); C().maceSwapDist = swap.get(); C().maceHitDist = hit.get(); C().maceAbortDist = abort.get(); C().minSelfHealth = hp.get();
              C().maceChainSwap = chainSw.get(); C().maceDropErr = err.get(); C().headHitTol = hTol.get(); C().headHitHoriz = hHz.get(); }; }

        { Module m = bridge("WindMace", "Mace liên tục (wind charge)", CB, () -> C().windMace, v -> { if (v != C().windMace) WindMace.toggle(MinecraftClient.getInstance()); });
          m.preview = 2;
          var rng = m.<Setting.Slider>add(new Setting.Slider("Tầm", C().windRange, 6, 40, 1));
          var st = m.<Setting.Slider>add(new Setting.Slider("Ném cách", C().windStartDist, 2, 10, 1));
          var cd = m.<Setting.Slider>add(new Setting.Slider("CD đập %", C().windMinCd, 20, 100, 1));
          m.apply = () -> { C().windRange = rng.get(); C().windStartDist = st.get(); C().windMinCd = cd.geti(); }; }

        { Module m = bridge("MacroCrystal", "Giữ chuột phải = nổ liên tục", CB, () -> C().crystalMacro, v -> C().crystalMacro = v);
          var per = m.<Setting.Slider>add(new Setting.Slider("Nổ / tick", C().macroPerTick, 1, 30, 1));
          var all = m.<Setting.Check>add(new Setting.Check("Nổ hết", C().macroAll));
          var place = m.<Setting.Check>add(new Setting.Check("Đặt lại", C().macroPlace));
          var dl = m.<Setting.Slider>add(new Setting.Slider("Delay", C().macroDelay, 0, 6, 1));
          m.apply = () -> { C().macroPerTick = per.geti(); C().macroAll = all.get(); C().macroPlace = place.get(); C().macroDelay = dl.geti(); }; }

        { Module m = bridge("AnchorShield", "Nổ anchor, tự chắn obsidian", CB, () -> C().anchorShield, v -> C().anchorShield = v);
          var glow = m.<Setting.Check>add(new Setting.Check("Dùng glowstone", C().anchorShieldGlow));
          var msg = m.<Setting.Check>add(new Setting.Check("Báo chat", C().anchorShieldMsg));
          m.apply = () -> { C().anchorShieldGlow = glow.get(); C().anchorShieldMsg = msg.get(); }; }

        { Module m = bridge("Aimbot", "Tự ngắm người", CB, () -> C().aimbot, v -> C().aimbot = v);
          var fov = m.<Setting.Slider>add(new Setting.Slider("FOV", C().aimFov, 5, 90, 1));
          var rng = m.<Setting.Slider>add(new Setting.Slider("Tầm", C().aimRange, 5, 60, 1));
          var sm = m.<Setting.Slider>add(new Setting.Slider("Mượt", C().aimSmooth, 0.05, 1, 0.05));
          m.apply = () -> { C().aimFov = fov.get(); C().aimRange = rng.get(); C().aimSmooth = sm.get(); }; }

        bridge("Surround", "Tự bao obsidian quanh chân", CB, () -> C().surround, v -> C().surround = v);

        // ================= TAB 2: MOVEMENT =================
        reg(new Module("Fly", "Bay", MV) {
            Setting.Mode mode = add(new Setting.Mode("Mode", 0, "Vanilla", "Glide"));
            Setting.Slider speed = add(new Setting.Slider("Speed", 0.05, 0.02, 0.5, 0.01));
            boolean had;
            @Override public void onEnable() { had = false; }
            @Override public void onDisable() { var mc = MinecraftClient.getInstance(); if (mc.player != null && !mc.player.isCreative() && !mc.player.isSpectator()) { mc.player.getAbilities().allowFlying = false; mc.player.getAbilities().flying = false; mc.player.getAbilities().setFlySpeed(0.05f); } }
            @Override public void onTick(MinecraftClient mc) {
                var p = mc.player; if (mode.is("Glide")) { if (!p.isOnGround() && p.getVelocity().y < -0.1) p.setVelocity(p.getVelocity().x, -0.1, p.getVelocity().z); return; }
                p.getAbilities().allowFlying = true; p.getAbilities().flying = true; p.getAbilities().setFlySpeed(speed.getf());
            } });

        reg(new Module("Speed", "Chạy nhanh", MV) {
            Setting.Slider mult = add(new Setting.Slider("Speed", 1.3, 1.0, 3.0, 0.05));
            Setting.Check air = add(new Setting.Check("Tăng cả khi trên không", false));
            @Override public void onTick(MinecraftClient mc) {
                var p = mc.player; if (!p.isOnGround() && !air.get()) return;
                if (p.forwardSpeed == 0 && p.sidewaysSpeed == 0) return;
                var v = p.getVelocity(); double hs = Math.hypot(v.x, v.z), max = 0.28 * mult.get();
                if (hs > 0.01 && hs < max) { double f = max / hs; p.setVelocity(v.x * f, v.y, v.z * f); }
            } });

        { Module m = bridge("Scaffold", "Tự bắc block dưới chân", MV, () -> C().bridgeOn, v -> C().bridgeOn = v); }
        stub("Jesus", "Đi trên nước", MV).add(new Setting.Mode("Mode", 0, "Solid", "Dolphin"));
        stub("NoSlow", "Không bị chậm khi ăn / chặn khiên", MV).add(new Setting.Slider("Slow %", 0, 0, 100, 1));
        stub("SafeWalk", "Không bị ngã vực", MV).add(new Setting.Check("Chỉ khi đứng sát mép", true));

        // ================= TAB 3: PLAYER =================
        reg(new Module("AutoEat", "Tự động ăn", PL) {
            Setting.Slider hunger = add(new Setting.Slider("Ăn khi đói <=", 14, 1, 19, 1));
            Setting.Check onlyGapple = add(new Setting.Check("Cho phép táo vàng", false));
            int prevSlot = -1;
            @Override public void onTick(MinecraftClient mc) {
                var p = mc.player; if (mc.currentScreen != null) return;
                if (p.getHungerManager().getFoodLevel() > hunger.geti()) { if (prevSlot >= 0) { mc.options.useKey.setPressed(false); p.getInventory().selectedSlot = prevSlot; prevSlot = -1; } return; }
                if (prevSlot < 0) {
                    int best = -1;
                    for (int i = 0; i < 9; i++) { ItemStack s = p.getInventory().getStack(i); if (s.get(DataComponentTypes.FOOD) == null) continue;
                        if (!onlyGapple.get() && (s.isOf(net.minecraft.item.Items.GOLDEN_APPLE) || s.isOf(net.minecraft.item.Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(net.minecraft.item.Items.POISONOUS_POTATO) || s.isOf(net.minecraft.item.Items.SPIDER_EYE))) continue;
                        best = i; break; }
                    if (best < 0) return;
                    prevSlot = p.getInventory().selectedSlot; p.getInventory().selectedSlot = best;
                }
                mc.options.useKey.setPressed(true);
            }
            @Override public void onDisable() { var mc = MinecraftClient.getInstance(); mc.options.useKey.setPressed(false); if (prevSlot >= 0 && mc.player != null) mc.player.getInventory().selectedSlot = prevSlot; prevSlot = -1; } });

        reg(new Module("AutoLog", "Tự thoát khi máu thấp", PL) {
            Setting.Slider hp = add(new Setting.Slider("Thoát khi máu <=", 6, 1, 19, 1));
            Setting.Check totems = add(new Setting.Check("Chỉ khi hết totem", true));
            @Override public void onTick(MinecraftClient mc) {
                var p = mc.player; if (p.getHealth() > hp.get()) return;
                if (totems.get() && (p.getOffHandStack().isOf(net.minecraft.item.Items.TOTEM_OF_UNDYING) || p.getMainHandStack().isOf(net.minecraft.item.Items.TOTEM_OF_UNDYING))) return;
                setEnabled(false);
                if (mc.getNetworkHandler() != null) mc.getNetworkHandler().getConnection().disconnect(net.minecraft.text.Text.literal("[LanAnh] AutoLog: máu " + String.format("%.1f", p.getHealth())));
            } });

        stub("ChestStealer", "Tự lấy đồ trong rương", PL).add(new Setting.Slider("Delay (ms)", 60, 0, 500, 10));
        stub("InventoryManager", "Tự sắp xếp kho đồ", PL).add(new Setting.Slider("Delay (ms)", 100, 0, 500, 10));
        stub("NoFall", "Không mất máu khi ngã", PL).add(new Setting.Mode("Mode", 0, "Packet", "Bucket"));

        // ================= TAB 4: RENDER =================
        { Module m = bridge("ESP", "Viền người / quái / đồ", RD, () -> C().espPlayers, v -> C().espPlayers = v);
          var mode = m.<Setting.Mode>add(new Setting.Mode("Mode", C().espMode, "Outline", "Fill", "Both"));
          var range = m.<Setting.Slider>add(new Setting.Slider("Range", C().espRange, 16, 256, 1));
          var mobs = m.<Setting.Check>add(new Setting.Check("Quái vật", C().espMobs));
          var col = m.<Setting.Color>add(new Setting.Color("Màu người chơi", C().espPlayerColor)); col.alpha = Math.min(255, C().espAlpha);
          m.apply = () -> { C().espMode = mode.index; C().espRange = range.get(); C().espMobs = mobs.get(); C().espPlayerColor = col.rainbow ? (col.argb() & 0xFFFFFF) : col.rgb; C().espAlpha = col.alpha; }; }

        { Module m = bridge("Tracers", "Đường chỉ tới mục tiêu", RD, () -> C().trPlayer > 0, v -> C().trPlayer = v ? 3 : 0);
          var from = m.<Setting.Mode>add(new Setting.Mode("Từ", 1, "Giữa", "Dưới"));
          var own = m.<Setting.Check>add(new Setting.Check("Màu riêng", C().tracerOwnColor));
          var col = m.<Setting.Color>add(new Setting.Color("Màu", C().tracerColor3));
          m.apply = () -> { if (C().trPlayer > 0) C().trPlayer = from.index + 2; C().tracerOwnColor = own.get(); C().tracerColor3 = col.rainbow ? (col.argb() & 0xFFFFFF) : col.rgb; }; }

        stub("Freecam", "Hồn lìa khỏi xác để đi soi", RD).add(new Setting.Slider("Speed", 1.0, 0.1, 5, 0.1));
        { Module m = bridge("StorageESP", "Viền rương, shulker box", RD, () -> C().espStorage, v -> C().espStorage = v);
          var chest = m.<Setting.Color>add(new Setting.Color("Rương", C().espChestColor));
          var ender = m.<Setting.Color>add(new Setting.Color("Ender chest", C().espEnderColor));
          var shulker = m.<Setting.Color>add(new Setting.Color("Shulker", C().espShulkerColor));
          m.apply = () -> { C().espChestColor = chest.rgb; C().espEnderColor = ender.rgb; C().espShulkerColor = shulker.rgb; }; }
        bridge("Nametags", "Tên to + hiện đồ", RD, () -> C().nameTags, v -> C().nameTags = v);

        scanMod("SusESP", "Block người đặt dưới lòng đất", "sus", () -> C().susBase, v -> C().susBase = v, true, true, false);
        { Module sm = scanMod("SpawnerESP", "Khung spawner xuyên tường", "spawner", () -> C().spawnerEsp, v -> C().spawnerEsp = v, false, false, false);
          var nat = sm.<Setting.Check>add(new Setting.Check("Cả lồng tự nhiên", C().spawnerNatural));
          Runnable prev = sm.apply;
          sm.apply = () -> { prev.run(); C().spawnerNatural = nat.get(); }; }
        scanMod("HoleESP", "Hố an toàn (obsidian / bedrock)", "hole", () -> C().holeEsp, v -> C().holeEsp = v, true, false, true);
        scanMod("Lightfinder", "Nguồn sáng lạ (đuốc, đèn...)", "light", () -> C().lightEsp, v -> C().lightEsp = v, true, false, false);
        { Module m = bridge("ChunkFinder", "Chunk có người ở", RD, () -> C().susOn, v -> C().susOn = v);
          Mods.Cfg g = Mods.cfg("chunk");
          var mn = m.<Setting.Slider>add(new Setting.Slider("Min Y", g.minY, -64, 320, 1));
          var mx = m.<Setting.Slider>add(new Setting.Slider("Max Y", g.maxY, -64, 320, 1));
          var cnt = m.<Setting.Slider>add(new Setting.Slider("Min block", C().susMin, 10, 300, 1));
          var dep = m.<Setting.Slider>add(new Setting.Slider("Sâu", C().susDepth, 1, 20, 1));
          m.apply = () -> { g.minY = mn.geti(); g.maxY = mx.geti(); C().susMin = cnt.geti(); C().susDepth = dep.geti(); }; }
        { Module m = bridge("Radar", "Radar người + block 2D", RD, () -> C().radarOn, v -> C().radarOn = v);
          var rng = m.<Setting.Slider>add(new Setting.Slider("Tầm", C().radarRange, 16, 128, 1));
          var size = m.<Setting.Slider>add(new Setting.Slider("Cỡ", C().radarSize, 50, 200, 1));
          var pl = m.<Setting.Check>add(new Setting.Check("Người", C().radarPlayers));
          var bl = m.<Setting.Check>add(new Setting.Check("Block", C().radarBlocks));
          var ic = m.<Setting.Check>add(new Setting.Check("Icon", C().radarIcons));
          var vt = m.<Setting.Check>add(new Setting.Check("Trên/dưới", C().radarVert));
          m.apply = () -> { C().radarRange = rng.get(); C().radarSize = size.geti(); C().radarPlayers = pl.get(); C().radarBlocks = bl.get(); C().radarIcons = ic.get(); C().radarVert = vt.get(); }; }
        { Module m = bridge("Trail", "Vệt sau lưng", RD, () -> C().trailOn, v -> C().trailOn = v);
          var len = m.<Setting.Slider>add(new Setting.Slider("Dài", C().trailLen, 10, 120, 1));
          var al = m.<Setting.Slider>add(new Setting.Slider("Alpha", C().trailAlpha, 20, 255, 1));
          m.apply = () -> { C().trailLen = len.geti(); C().trailAlpha = al.geti(); }; }
        { Module m = bridge("TpGlide", "Camera trượt khi tp", RD, () -> C().tpGlide, v -> C().tpGlide = v);
          var ms = m.<Setting.Slider>add(new Setting.Slider("Thời gian (ms)", C().tpMs, 150, 1500, 10));
          var mn = m.<Setting.Slider>add(new Setting.Slider("Tối thiểu (block)", C().tpMin, 2, 30, 1));
          m.apply = () -> { C().tpMs = ms.geti(); C().tpMin = mn.get(); }; }

        // ================= TAB 5: WORLD =================
        { Module m = bridge("PacketMiner", "Tự đào quặng", WO, () -> C().mineOn, v -> C().mineOn = v);
          var rng = m.<Setting.Slider>add(new Setting.Slider("Range", C().mineRange, 4, 48, 1));
          m.apply = () -> C().mineRange = rng.get(); }
        { Module m = bridge("FreeDig", "Freecam chọn vùng, bot tự đào", WO, () -> FreeDig.on, v -> FreeDig.setOn(v));
          var sp = m.<Setting.Slider>add(new Setting.Slider("Tốc độ bay", C().fdSpeed, 3, 60, 1));
          var rg = m.<Setting.Slider>add(new Setting.Slider("Tầm bay", C().fdRange, 30, 160, 1));
          m.apply = () -> { C().fdSpeed = sp.geti(); C().fdRange = rg.geti(); }; }
        { Module m = bridge("BaseFinder", "Tìm chỗ xây base không hang", WO, () -> C().bfOn, v -> C().bfOn = v);
          var open = m.<Setting.Check>add(new Setting.Check("Mở bảng nhập X Z", false));
          var far = m.<Setting.Slider>add(new Setting.Slider("Xa hang (chunk)", C().bfFar, 0, 10, 1));
          var tol = m.<Setting.Slider>add(new Setting.Slider("Dung sai", C().bfTol, 0, 3000, 50));
          var yy = m.<Setting.Slider>add(new Setting.Slider("Y xây", C().bfY, -60, 300, 1));
          var maxY = m.<Setting.Slider>add(new Setting.Slider("Hang từ Y ≤", C().bfMaxY, -60, 64, 1));
          var caves = m.<Setting.Check>add(new Setting.Check("Hiện chunk hang", C().bfCaves));
          var sch = m.<Setting.Check>add(new Setting.Check("Theo schematic", C().bfSchem));
          m.apply = () -> { C().bfFar = far.geti(); C().bfTol = tol.geti(); C().bfY = yy.geti(); C().bfMaxY = maxY.geti(); C().bfCaves = caves.get(); C().bfSchem = sch.get();
              if (open.get()) { open.value = false; var mc = MinecraftClient.getInstance(); mc.execute(() -> mc.setScreen(new BaseFinderScreen(mc.currentScreen))); } }; }
        { Module m = bridge("TunnelDig", "Đào hầm thẳng (cúp thường / Amethyst)", WO, () -> TunnelDig.on, v -> TunnelDig.setOn(v));
          var mode = m.<Setting.Mode>add(new Setting.Mode("Kiểu", C().tnMode, "Cúp thường", "Amethyst 3x3"));
          var dir = m.<Setting.Mode>add(new Setting.Mode("Hướng", C().tnDir, "Theo nhìn", "Bắc", "Nam", "Đông", "Tây", "Xuống"));
          var floor = m.<Setting.Check>add(new Setting.Check("Vá sàn", C().tnFloor));
          var safe = m.<Setting.Check>add(new Setting.Check("Né lava", C().tnSafe));
          var len = m.<Setting.Slider>add(new Setting.Slider("Dài (0 = mãi)", C().tnLen, 0, 500, 1));
          m.apply = () -> { C().tnMode = mode.index; C().tnDir = dir.index; C().tnFloor = floor.get(); C().tnSafe = safe.get(); C().tnLen = len.geti(); }; }
        stub("AutoSign", "Tự viết biển", WO).add(new Setting.Check("Dùng lại dòng cũ", true));
        stub("MountBypass", "Cưỡi động vật không cần yên", WO);
        stub("Timer", "Tăng tốc độ game", WO).add(new Setting.Slider("Multiplier", 1.5, 0.1, 5, 0.1));

        // ================= TAB 6: MISC =================
        stub("AutoReconnect", "Tự kết nối lại khi rớt mạng", MI).add(new Setting.Slider("Delay (s)", 5, 1, 30, 1));
        reg(new Module("AntiAFK", "Chống bị kick do treo máy", MI) {
            Setting.Slider every = add(new Setting.Slider("Mỗi (giây)", 20, 5, 120, 1));
            Setting.Check jump = add(new Setting.Check("Nhảy", true));
            Setting.Check rot = add(new Setting.Check("Xoay camera nhẹ", true));
            @Override public void onTick(MinecraftClient mc) {
                var p = mc.player; if (p.age % (every.geti() * 20) != 0) return;
                if (jump.get() && p.isOnGround()) p.setVelocity(p.getVelocity().x, 0.42, p.getVelocity().z);
                if (rot.get()) p.setYaw(p.getYaw() + (p.age / 20 % 2 == 0 ? 8 : -8));
            } });
        { Module m = bridge("Translate", "Dịch chat như Google Dịch", MI, () -> C().trOn, v -> C().trOn = v);
          var out = m.<Setting.Check>add(new Setting.Check("Gửi", C().chatOut));
          var in = m.<Setting.Check>add(new Setting.Check("Nhận", C().chatIn));
          var lo = m.<Setting.Mode>add(new Setting.Mode("Gửi sang", Translate.langIndex(C().trOut), Translate.LANGS));
          var li = m.<Setting.Mode>add(new Setting.Mode("Nhận sang", Translate.langIndex(C().trIn), Translate.LANGS));
          m.apply = () -> { C().chatOut = out.get(); C().chatIn = in.get(); C().trOut = Translate.LANGS[lo.index]; C().trIn = Translate.LANGS[li.index]; }; }
        stub("ChatChannels", "Tách kênh chat", MI);

        { Module m = bridge("KeySound", "Âm bàn phím cơ (Creamy)", MI, () -> C().keySound, v -> C().keySound = v);
          var type = m.<Setting.Mode>add(new Setting.Mode("Loại", Math.min(KeySound.PACK_NAMES.length - 1, C().keySoundType), KeySound.PACK_NAMES));
          var all = m.<Setting.Mode>add(new Setting.Mode("Toàn game", C().keySoundAll, "Tắt", "Giao diện", "Mọi tiếng"));
          var vol = m.<Setting.Slider>add(new Setting.Slider("Âm lượng %", C().keySoundVol, 0, 100, 1));
          var pit = m.<Setting.Slider>add(new Setting.Slider("Pitch %", C().keySoundPitch, 50, 200, 1));
          var rel = m.<Setting.Check>add(new Setting.Check("Tiếng nhả", C().keySoundRelease));
          m.apply = () -> { C().keySoundType = type.index; C().keySoundAll = all.index; C().keySoundVol = vol.geti(); C().keySoundPitch = pit.geti(); C().keySoundRelease = rel.get(); }; }
        { Module m = bridge("Chế độ", "Safe / Risk / Unsafe", MI, () -> true, v -> {});
          var mode = m.<Setting.Mode>add(new Setting.Mode("Mode", C().mode, "Safe", "Risk", "Unsafe"));
          m.apply = () -> C().mode = mode.index; }
        { Module m = bridge("Giao diện", "Nền menu (ảnh: config/lananh-bg.png)", MI, () -> true, v -> {});
          bgMode = m.<Setting.Mode>add(new Setting.Mode("Nền", 0, "Tối", "Màu", "Gradient", "Ảnh"));
          bgC1 = m.<Setting.Color>add(new Setting.Color("Màu 1", 0x0B0B14)); bgC1.alpha = 255;
          bgC2 = m.<Setting.Color>add(new Setting.Color("Màu 2", 0x3B1A6E)); bgC2.alpha = 255;
          bgDim = m.<Setting.Slider>add(new Setting.Slider("Độ tối", 90, 0, 255, 1));
          bgPanel = m.<Setting.Slider>add(new Setting.Slider("Khung giữa", 240, 0, 255, 1));
          bgTrans = m.<Setting.Slider>add(new Setting.Slider("Trong suốt %", 0, 0, 90, 1));
          m.apply = () -> C().uiTrans = bgTrans.geti(); }

        // ================= TAB 7: HUD =================
        reg(new Module("Armor", "Độ bền giáp", HD) {
            Setting.Check pct = add(new Setting.Check("Hiện %", true));
            Setting.Slider x = add(new Setting.Slider("X (%)", 50, 0, 100, 1)); Setting.Slider y = add(new Setting.Slider("Y (%)", 88, 0, 100, 1));
            @Override public void onHud(DrawContext ctx, MinecraftClient mc) {
                int W = ctx.getScaledWindowWidth(), H = ctx.getScaledWindowHeight(), px = (int) (W * x.get() / 100) - 40, py = (int) (H * y.get() / 100), i = 0;
                for (int s = 3; s >= 0; s--) { ItemStack st = mc.player.getInventory().armor.get(s); if (st.isEmpty()) continue;
                    int cx = px + i++ * 22; ctx.drawItem(st, cx, py);
                    if (pct.get() && st.getMaxDamage() > 0) { int left = 100 - st.getDamage() * 100 / st.getMaxDamage(); ctx.drawText(mc.textRenderer, left + "%", cx, py + 17, left > 50 ? 0xFF55FF55 : left > 20 ? 0xFFFFFF55 : 0xFFFF5555, true); } }
            } });
        reg(new Module("Coordinates", "Tọa độ X Y Z", HD) {
            Setting.Color col = add(new Setting.Color("Màu", 0xFFFFFF));
            Setting.Check nether = add(new Setting.Check("Quy đổi Nether/Overworld", true));
            @Override public void onHud(DrawContext ctx, MinecraftClient mc) {
                var p = mc.player; String s = String.format("XYZ: %d %d %d", (int) Math.floor(p.getX()), (int) Math.floor(p.getY()), (int) Math.floor(p.getZ()));
                if (nether.get()) { boolean n = mc.world.getRegistryKey() == net.minecraft.world.World.NETHER; s += String.format("  [%s %d %d]", n ? "OW" : "NE", (int) Math.floor(n ? p.getX() * 8 : p.getX() / 8), (int) Math.floor(n ? p.getZ() * 8 : p.getZ() / 8)); }
                ctx.drawText(mc.textRenderer, s, 4, ctx.getScaledWindowHeight() - 12, col.argb() | 0xFF000000, true);
            } });
        reg(new Module("FPS / Ping", "Hiệu năng và mạng", HD) {
            Setting.Check fps = add(new Setting.Check("FPS", true)); Setting.Check ping = add(new Setting.Check("Ping", true));
            Setting.Color col = add(new Setting.Color("Màu", 0xFF69B4));
            @Override public void onHud(DrawContext ctx, MinecraftClient mc) {
                StringBuilder sb = new StringBuilder();
                if (fps.get()) sb.append("FPS ").append(mc.getCurrentFps());
                if (ping.get()) { var e = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()); sb.append(sb.length() > 0 ? "  " : "").append("Ping ").append(e == null ? 0 : e.getLatency()).append("ms"); }
                ctx.drawText(mc.textRenderer, sb.toString(), 4, 4 + 14, col.argb() | 0xFF000000, true);
            } });
        reg(new Module("Inventory", "Xem nhanh 27 ô đồ", HD) {
            Setting.Slider x = add(new Setting.Slider("X (px)", 4, 0, 400, 1)); Setting.Slider y = add(new Setting.Slider("Y (px)", 40, 0, 300, 1));
            @Override public void onHud(DrawContext ctx, MinecraftClient mc) {
                int bx = x.geti(), by = y.geti(); ctx.fill(bx - 2, by - 2, bx + 9 * 18 + 2, by + 3 * 18 + 2, 0x90000000);
                for (int i = 0; i < 27; i++) { ItemStack st = mc.player.getInventory().getStack(9 + i); int cx = bx + (i % 9) * 18, cy = by + (i / 9) * 18; ctx.drawItem(st, cx, cy); ctx.drawStackOverlay(mc.textRenderer, st, cx, cy); }
            } });
    }

    // ---------------- tick / phím tắt ----------------
    public static void tick(MinecraftClient mc) {
        if (mc.getWindow() == null) return;
        long h = mc.getWindow().getHandle();
        boolean inGame = mc.player != null && mc.world != null;
        for (Module m : ALL) {
            int k = m.bind.key;
            if (k >= 32 && k <= 348 && !m.bind.listening) {
                boolean now = mc.currentScreen == null && GLFW.glfwGetKey(h, k) == GLFW.GLFW_PRESS, was = down.getOrDefault(m.name, false);
                down.put(m.name, now);
                if (now && !was && inGame) { m.toggle(); Util.msg(m.name + ": " + (m.isOn() ? "§aBẬT" : "§cTẮT")); }
            }
            if (m.apply != null) {                                       // chỉ đẩy sang Config khi bạn chỉnh Setting (menu cũ chỉnh Config sẽ không bị ghi đè nữa)
                long sg = 17;
                for (Setting s : m.settings) sg = sg * 31 + s.sig();
                Long lastSg = lastSig.get(m.name);
                if (lastSg == null || lastSg != sg) { lastSig.put(m.name, sg); try { m.apply.run(); } catch (Throwable ignored) {} }
            }
            if (inGame && m.isOn() && m.ext == null) { try { m.onTick(mc); } catch (Throwable t) { t.printStackTrace(); m.setEnabled(false); } }
        }
    }

    public static void hud(DrawContext ctx) {
        var mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        for (Module m : ALL) if (m.cat == Module.Cat.HUD && m.isOn()) { try { m.onHud(ctx, mc); } catch (Throwable t) { m.setEnabled(false); } }
    }

    // ---------------- lưu / tải ----------------
    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : ALL) {
                JsonObject o = new JsonObject(); o.addProperty("on", m.isOn()); o.addProperty("key", m.bind.key);
                JsonObject st = new JsonObject(); for (Setting s : m.settings) s.save(st); o.add("s", st);
                root.add(m.name, o);
            }
            Files.writeString(file(), GSON.toJson(root));
        } catch (Exception ignored) {}
    }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            JsonObject root = JsonParser.parseString(Files.readString(file())).getAsJsonObject();
            for (Module m : ALL) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("key")) m.bind.key = o.get("key").getAsInt();
                if (o.has("s")) { JsonObject st = o.getAsJsonObject("s"); for (Setting s : m.settings) { try { s.load(st); } catch (Exception ignored) {} } }
                if (m.ext == null && o.has("on")) m.enabled = false;   // module native luôn khởi động ở trạng thái TẮT cho an toàn
            }
        } catch (Exception ignored) {}
    }
}
