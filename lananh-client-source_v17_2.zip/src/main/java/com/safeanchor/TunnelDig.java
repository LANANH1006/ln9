package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Đào hầm thẳng theo 1 hướng (Bắc / Nam / Đông / Tây hoặc theo hướng đang nhìn, hoặc xuống bậc thang).
 * Kiểu 0 "Cúp thường": hầm 1x2, đào từng block bằng cúp.
 * Kiểu 1 "Amethyst": đứng GIỮA, đào mặt 3x3 phía trước (hàng chân + 2 hàng trên, mỗi bên 1 block): đào block giữa trước, cúp amethyst
 * sẽ phá luôn 9 khối; ô nào còn sót thì mod đào nốt.
 * Mỗi bước: đào hết ô phía trước -> nếu sàn phía trước bị hở thì cúi xuống đặt 1 block vá sàn (block thường) -> bước tới.
 */
public class TunnelDig {
    public static boolean on;
    static Direction dir;
    static int dug, stuck;
    static BlockPos lastPos;
    static boolean held;
    static final Set<Block> JUNK = Set.of(Blocks.COBBLESTONE, Blocks.DIRT, Blocks.NETHERRACK, Blocks.COBBLED_DEEPSLATE, Blocks.STONE, Blocks.ANDESITE,
            Blocks.DIORITE, Blocks.GRANITE, Blocks.TUFF, Blocks.DEEPSLATE);

    public static void setOn(boolean v) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (v == on) return;
        if (v && mc.player == null) { Util.msg("Vào thế giới rồi mới bật"); return; }
        on = v; dir = null; dug = 0; stuck = 0;
        if (!v) release(mc);
        else Util.msg("Đào hầm: " + (Config.I.tnMode == 1 ? "Amethyst 3x3" : "Cúp thường"));
    }

    static void release(MinecraftClient mc) {
        if (held) { mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); held = false; }
    }

    static void stop(MinecraftClient mc, String why) {
        Util.msg("Đào hầm dừng: " + why);
        setOn(false);
        Config.save(); ModuleManager.save();
    }

    static Direction pickDir(net.minecraft.client.network.ClientPlayerEntity p) {
        return switch (Config.I.tnDir) {
            case 1 -> Direction.NORTH; case 2 -> Direction.SOUTH; case 3 -> Direction.EAST; case 4 -> Direction.WEST;
            default -> Direction.fromHorizontalDegrees(p.getYaw());
        };
    }

    static boolean solidFloor(World w, BlockPos p) {
        BlockState s = w.getBlockState(p);
        return !s.getCollisionShape(w, p).isEmpty() && s.getFluidState().isEmpty();
    }

    static boolean junk(ItemStack s) { return s.getItem() instanceof BlockItem bi && JUNK.contains(bi.getBlock()); }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (!on) return;
        if (p == null || w == null || mc.interactionManager == null) { on = false; return; }
        if (mc.currentScreen != null || !c.enabled) return;
        if (dir == null) dir = pickDir(p);
        boolean stair = c.tnDir == 5;
        if (stair && dir == null) dir = Direction.fromHorizontalDegrees(p.getYaw());
        if (c.tnLen > 0 && dug >= c.tnLen) { stop(mc, "đã đào đủ " + dug + " block"); return; }

        BlockPos feet = p.getBlockPos();
        BlockPos ahead = feet.offset(dir);
        Direction side = dir.rotateYClockwise();
        int half = c.tnMode == 1 ? 1 : 0;                       // Amethyst: rộng 3
        int y0 = stair ? -1 : 0, y1 = c.tnMode == 1 ? 2 : 1;    // Amethyst: cao 3 (chân + 2 hàng trên)
        List<BlockPos> cells = new ArrayList<>();
        for (int l = -half; l <= half; l++) for (int dy = y0; dy <= y1; dy++) cells.add(ahead.offset(side, l).up(dy));
        cells.sort((a, b) -> Double.compare(Vec3d.ofCenter(a).squaredDistanceTo(Vec3d.ofCenter(ahead.up())), Vec3d.ofCenter(b).squaredDistanceTo(Vec3d.ofCenter(ahead.up()))));   // block giữa trước

        // 1) đào hết các ô phía trước
        for (BlockPos cell : cells) {
            if (AutoMine.passable(w, cell)) continue;
            if (c.tnSafe && (AutoMine.lava(w, cell) || AutoMine.nearLava(w, cell))) { stop(mc, "gặp lava"); return; }
            if (!AutoMine.breakable(w, cell)) { stop(mc, "gặp block không đào được (" + cell.toShortString() + ")"); return; }
            release(mc);
            AutoMine.mine(mc, cell);
            stuck = 0;
            return;
        }

        // 2) sàn phía trước hở -> cúi xuống đặt 1 block thường
        BlockPos stand = ahead.up(stair ? -1 : 0);
        BlockPos floor = stand.down();
        if (c.tnFloor && !solidFloor(w, floor)) {
            if (c.tnSafe && AutoMine.lava(w, floor)) { stop(mc, "sàn phía trước là lava"); return; }
            release(mc);
            if (!Util.has(TunnelDig::junk)) { stop(mc, "hết block để vá sàn"); return; }
            Util.aim(p, Vec3d.ofCenter(floor));                  // quay xuống nhìn ô sàn
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (junk(s) && Util.placeBlock(floor, s.getItem())) return;
            }
            return;
        }

        // 3) bước tới
        Vec3d to = Vec3d.ofBottomCenter(stand);
        Util.aim(p, new Vec3d(to.x, p.getEyeY(), to.z));
        mc.options.forwardKey.setPressed(true); held = true;
        mc.options.jumpKey.setPressed(!stair && p.horizontalCollision && p.isOnGround());
        if (Math.hypot(p.getX() - to.x, p.getZ() - to.z) < 0.3 && Math.abs(p.getY() - stand.getY()) < 0.9) { dug++; stuck = 0; }
        if (p.getBlockPos().equals(lastPos)) { if (++stuck > 100) { stop(mc, "bị kẹt"); } } else { stuck = 0; lastPos = p.getBlockPos(); }
    }
}
