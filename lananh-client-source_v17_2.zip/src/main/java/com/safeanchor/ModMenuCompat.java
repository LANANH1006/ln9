package com.safeanchor;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/** Mod Menu: ở màn hình chính -> Mods -> tìm "lan anh client" -> bấm nút cài đặt là mở thẳng Module Menu, không cần vào game. */
public class ModMenuCompat implements ModMenuApi {
    @Override public ConfigScreenFactory<?> getModConfigScreenFactory() { return parent -> new ModulesScreen(parent); }
}
