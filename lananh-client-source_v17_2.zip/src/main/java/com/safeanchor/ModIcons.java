package com.safeanchor;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.HashMap;
import java.util.Map;

/** Icon item 2D cho từng module (nút ElytraMace = hình cục mace, ESP = mắt ender...). */
public class ModIcons {
    static final Map<String, Item> BY_NAME = new HashMap<>();
    static {
        BY_NAME.put("ElytraMace", Items.MACE);
        BY_NAME.put("WindMace", Items.WIND_CHARGE);
        BY_NAME.put("MacroCrystal", Items.END_CRYSTAL);
        BY_NAME.put("AnchorShield", Items.RESPAWN_ANCHOR);
        BY_NAME.put("Aimbot", Items.BOW);
        BY_NAME.put("Surround", Items.OBSIDIAN);
        BY_NAME.put("KillAura", Items.DIAMOND_SWORD);
        BY_NAME.put("Triggerbot", Items.CROSSBOW);
        BY_NAME.put("Velocity", Items.SHIELD);
        BY_NAME.put("BedAura", Items.RED_BED);
        BY_NAME.put("ESP", Items.ENDER_EYE);
        BY_NAME.put("Tracers", Items.STRING);
        BY_NAME.put("Nametags", Items.NAME_TAG);
        BY_NAME.put("SusESP", Items.DEEPSLATE_BRICKS);
        BY_NAME.put("SpawnerESP", Items.SPAWNER);
        BY_NAME.put("HoleESP", Items.BEDROCK);
        BY_NAME.put("Lightfinder", Items.TORCH);
        BY_NAME.put("ChunkFinder", Items.COMPASS);
        BY_NAME.put("Radar", Items.RECOVERY_COMPASS);
        BY_NAME.put("Trail", Items.FEATHER);
        BY_NAME.put("TpGlide", Items.ENDER_PEARL);
        BY_NAME.put("PacketMiner", Items.DIAMOND_PICKAXE);
        BY_NAME.put("FreeDig", Items.SPYGLASS);
        BY_NAME.put("TunnelDig", Items.AMETHYST_SHARD);
        BY_NAME.put("BaseFinder", Items.FILLED_MAP);
        BY_NAME.put("Translate", Items.WRITABLE_BOOK);
        BY_NAME.put("KeySound", Items.NOTE_BLOCK);
        BY_NAME.put("Chế độ", Items.REDSTONE_TORCH);
        BY_NAME.put("Giao diện", Items.PAINTING);
    }

    public static Item of(Module m) {
        Item it = BY_NAME.get(m.name);
        if (it != null) return it;
        return switch (m.cat) {
            case COMBAT -> Items.IRON_SWORD;
            case MOVEMENT -> Items.LEATHER_BOOTS;
            case PLAYER -> Items.PLAYER_HEAD;
            case RENDER -> Items.ENDER_EYE;
            case WORLD -> Items.GRASS_BLOCK;
            case MISC -> Items.COMPARATOR;
            case HUD -> Items.PAINTING;
        };
    }

    public static void draw(DrawContext ctx, Item it, int x, int y, float scale) {
        var ms = ctx.getMatrices();
        ms.push();
        ms.translate(x, y, 0);
        ms.scale(scale, scale, 1f);
        ctx.drawItem(new ItemStack(it), 0, 0);
        ms.pop();
    }
}
