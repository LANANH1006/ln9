package com.safeanchor;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Config {
    public static Config I = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("safeanchor.json"); }

    public static void load() {
        try { if (Files.exists(file())) { Config c = GSON.fromJson(Files.readString(file()), Config.class); if (c != null) I = c; } }
        catch (Exception ignored) {}
    }
    public static void save() { try { Files.writeString(file(), GSON.toJson(I)); } catch (Exception ignored) {} }

    // ---- chung ----
    public boolean enabled = true;
    public boolean showTitle = true;
    public boolean autoTotem = false;
    public int totemSlot = 5;      // ô hotbar chứa totem (1-9)
    public int spareSlot = 8;      // ô hotbar tạm để đổi đồ từ túi (1-9)
    public double reach = 4.5;

    // ---- elytra mace ----
    public boolean autoMace = false;
    public int maceView = 0;       // 0 giữ nguyên, 1 ngôi 1, 2 ngôi 3 sau, 3 ngôi 3 trước
    public double maceRange = 128;
    public double maceDiveDist = 12;
    public double maceHorizDive = 14;
    public double maceSwapDist = 14;   // còn cách đối thủ bao nhiêu block thì đổi cánh -> áo để rơi đập
    public double maceAbortDist = 10;  // đối thủ lệch ngang quá số này (pearl/chạy) thì bỏ, bay lên lại
    public double minSelfHealth = 6;
    public boolean maceSwapChest = true;
    public boolean maceUseRocket = true;

    // ---- crystal / pearl ----
    public boolean crystal = false;
    public boolean crystalAutoObs = true;
    public boolean pearlCrystal = true;
    public double crystalRange = 4.5;
    public double crystalExplodeDist = 5.0;
    public double maxSelfDamage = 8;
    public int crystalDelay = 2;

    // ---- anchor ----
    public boolean anchor = false;
    public boolean anchorSafe = true;

    // ---- esp ----
    public boolean espPlayers = false, espMobs = false, espStorage = false, espBlocks = false;
    public int espMode = 2;        // 0 viền, 1 đặc, 2 cả hai
    public int espAlpha = 90;
    public double espRange = 128;
    public int espPlayerColor = 0xFF10F0, espMobColor = 0xFFA040, espChestColor = 0xE0B040,
            espEnderColor = 0xA040FF, espShulkerColor = 0xFF60C0;
    // dây tracer: 0 tắt, 1 trên màn hình, 2 giữa màn hình, 3 dưới màn hình
    public int trPlayer = 3, trMob = 0, trChest = 0, trEnder = 0, trShulker = 0, trBlock = 0;
    public boolean tracerOwnColor = false;
    public int tracerColor1 = 0xFFFFFF, tracerColor2 = 0x00FFFF, tracerColor3 = 0xFF69B4;

    // ---- pearl phát sáng ----
    public boolean pearlGlow = true;
    public int pearlGlowColor = 0xFF10F0;

    // ---- quỹ đạo ném / cung, máu, schematic, dây ----
    public boolean trajOn = true, healthTag = false, schemGhost = true;
    public int tracerOffset = 0;      // kéo dây lên/xuống (-80..80)

    public double maceHitDist = 3.0;   // tự đập khi cách đối thủ <= số này
    public boolean surround = false;

    // ---- aimbot ----
    public boolean aimbot = false, aimCircle = true, aimPlayers = true, aimVisibleOnly = true;
    public double aimFov = 25;       // bán kính vòng tròn (độ)
    public double aimRange = 30;
    public double aimSmooth = 0.35;  // 0.05 chậm - 1 khóa ngay
    public int aimColor = 0xFF69B4;

    // ---- block esp ----
    public boolean espBlkOres = true, espBlkUtility = false, espBlkSpecial = true;
    public int espBlkOreColor = 0x40E0FF, espBlkUtilityColor = 0xC0C0C0, espBlkSpecialColor = 0xFF4040, espBlkCustomColor = 0x40FF40;
    public double espBlkRange = 48;
    public List<String> espBlkCustom = new ArrayList<>();

    // ---- hud ----
    public boolean counterOn = false;
    public int counterX = 1, counterY = 12;       // phần trăm màn hình
    public boolean radarOn = false, radarPlayers = true, radarBlocks = true;
    public int radarX = 99, radarY = 12, radarSize = 90;
    public double radarRange = 48;

    // ---- printer (schematic) ----
    public boolean printerOn = false;
    public int printerDelay = 2;
    public int printerPerTick = 1;
    public double printerRange = 4.5;
    public boolean printerFixRotate = true;
    public boolean printerClicks = true;
    public boolean printerSneak = true;

    // ---- v2.3 ----
    public int espBlkAlpha = 90;                 // độ đậm màu block ESP
    public boolean maceSpam = false, maceSpamFast = true;
    public boolean autoPvp = false, pvpCrystal = true, pvpWalk = true;
    public double pvpRange = 3.8, pvpSmooth = 0.6;
    public int printerLayerMode = 1;             // 0 tắt, 1 xây từ dưới lên, 2 xây từ trên xuống
    public boolean printerLook = false, printerWalk = false;
    public boolean ahOn = false;
    public String ahKeyword = "";
    public double ahMaxPrice = 0;
    public int ahInterval = 80;
    public boolean susOn = false;
    public int susMin = 40, susDepth = 3;
    public boolean mineOn = false;
    public double mineRange = 16;
    public List<String> mineList = new ArrayList<>(List.of("diamond_ore", "deepslate_diamond_ore", "ancient_debris"));
    public boolean chatIn = true, chatOut = true;        // Dịch: nhận (đổi thẳng chat người khác) / gửi (đổi tin bạn gõ)
    public boolean trOn = false;                          // công tắc tổng của Translate
    public String trOut = "en", trIn = "vi";              // gửi sang / nhận sang

    // ---- v2.4 ----
    public boolean chroma = false;
    public boolean shockOn = false, shockJump = true, shockLand = true, shockBlock = true;
    public double shockRadius = 4.0, shockHeight = 1.2, shockMinFall = 2.0;
    public int shockTicks = 14, shockColor = 0xFF69B4;
    public boolean trailOn = false, trailChroma = false;
    public int trailLen = 40, trailColor1 = 0xFF69B4, trailColor2 = 0x8B5CF6, trailAlpha = 200;
    public double trailHeight = 0.9;
    public boolean skyOn = false;
    public int skyTime = 18000;
    public boolean hudFps = true, hudPing = true, hudRam = false, hudCoords = false, hudKeys = false;
    public int hudColor = 0xFF69B4;
    public boolean velOn = false;
    public int velH = 20, velV = 100;
    public int comboDelay = 2;
    public boolean comboObs = true;

    // ---- v2.5 (học từ PURXIY) ----
    public boolean ringJump = false, ringHit = false;
    public int ringColor = 0xFF69B4, ringHitColor = 0x8B5CF6, ringTicks = 14;
    public double ringSize = 2.5;
    public boolean glideOn = false;
    public int glideColor = 0xA855F7, glideSpeed = 35;
    public boolean placeAnimOn = false;
    public int placeColor = 0xFF69B4, placeTicks = 10;
    public boolean trigOn = false, hitSelect = false, pvpSilent = false;
    public int hitSelectMin = 90;
    public boolean hudPotion = false, hudArmor = false, hudArray = false, hudCombo = false;

    public static String exportJson() { return GSON.toJson(I); }
    public static boolean importJson(String s) {
        try { Config c = GSON.fromJson(s, Config.class); if (c == null) return false; I = c; save(); return true; }
        catch (Exception e) { return false; }
    }
    public static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("lananh-configs"); }

    // ---- v2.6 ----
    public boolean crossRing = false, hitSplash = false, targetEsp = false, radiance = false, afterglow = false;
    public boolean gridOn = false, tileOn = false, bridgeOn = false, nameTags = false, hudTotem = false;
    public int crossColor = 0xFF69B4, splashColor = 0xFF69B4, targetColor = 0xFF69B4, radianceColor = 0xA855F7;
    public int gridColor = 0xA855F7, tileColor = 0xFF69B4, gridRadius = 10, tileRadius = 6;

    // ---- v2.7 ----
    public boolean noOpenContainer = true;              // click rương/hopper/shulker... không mở (ngồi shift để mở)
    public boolean maceAutoHit = true, maceChain = true;
    public double maceChainSwap = 4.0;                  // chuỗi đập: cách đối thủ bao nhiêu thì đổi cánh -> áo
    public boolean crystalMacro = false;                // cầm crystal + giữ chuột phải vào obsidian = tự nổ
    public int macroDelay = 0;
    public int trailPos = 0;                            // 0 dưới chân, 1 giữa người, 2 trên đầu
    public boolean crossCustom = false;
    public int crossScale = 2, crossDrawColor = 0xFFFFFF;
    public String crossPix = CrossPix.plus();
    public boolean skyColorOn = false;
    public int skyTopColor = 0xBFE3FF, skyHorizonColor = 0xFFE9F3;

    // ---- v3 ----
    public boolean maceAxe = true;          // đối thủ giơ khiên -> tự đổi rìu đập phá khiên rồi quay lại mace
    public boolean macroPlace = true;       // macro crystal: tự đặt crystal lại liên tục (không chờ game lặp chuột phải)

    // ---- mace liên tục (wind charge combo) ----
    public boolean windMace = false;
    public double windRange = 16, windStartDist = 5;
    public int windMinCd = 50;     // % cooldown tối thiểu để đập (đổi ô tay làm cooldown reset)

    // ---- v2.9 ----
    public boolean radarIcons = true, radarVert = true;            // radar: icon block 2D, báo trên/dưới
    public boolean maceLock = true;                                // khóa đúng 1 mục tiêu cho tới khi chết / mất
    public boolean maceSearch = true;                              // không thấy đối thủ -> bay elytra đi tìm
    public int maceSearchSec = 60;                                 // tìm tối đa bao nhiêu giây
    public int maceStyle = 1;                                      // 0 = thả rơi đập, 1 = lao pháo (elytra + pháo lao xuống đập rồi bay lên lại)
    public boolean maceChase = true;                               // đối thủ chạy / pearl xa -> bay elytra đón đầu
    public boolean maceBallistic = true;                           // thả rơi thẳng theo đà thay vì lao chéo
    public double maceDropErr = 1.6;                               // sai số điểm thả (block)
    public boolean headHit = true;                                 // cầm mace, đang rơi, chân ngang đầu đối thủ -> đánh luôn
    public double headHitTol = 0.6, headHitHoriz = 1.4;
    public List<String> macroSeq = new ArrayList<>(List.of("ANCHOR", "GLOW", "OBS_SHIELD", "TOTEM", "EXPLODE"));
    public int macroSlotPick = 1, macroWaitPick = 2;
    public boolean tpGlide = true;                                 // trượt camera mượt khi bị tp (pearl, chorus...)
    public int tpMs = 450;
    public double tpMin = 5.0;
    public boolean keySound = false, keySoundRelease = false;

    // ---- v2.10 ----
    public boolean anchorShield = true;        // bấm nổ anchor (đã nạp 1-4 glowstone) -> đặt ngay 1 block chắn phía mình
    public boolean anchorShieldGlow = true;    // hết obsidian thì dùng glowstone
    public boolean anchorShieldMsg = false;
    public int mode = 1;                       // 0 Safe (chậm, ngẫu nhiên như người) / 1 Risk / 2 Unsafe (tối đa)
    public boolean susBase = false, spawnerEsp = false, holeEsp = false, lightEsp = false;
    public java.util.Map<String, Mods.Cfg> mods = new java.util.HashMap<>();
    public int macroPerTick = 30;              // Macro Crystal: đập tối đa bao nhiêu crystal / tick (1-30)
    public boolean macroAll = true;            // đập mọi crystal trong tầm (tắt = chỉ crystal trên block đang ngắm)
    public int keySoundType = 0, keySoundPitch = 100, keySoundVol = 80, keySoundAll = 2;   // keySoundAll: 0 tắt, 1 giao diện, 2 mọi tiếng trong game
    // Tìm chỗ xây base không hang
    public boolean bfOn = false, bfSchem = false, bfCaves = true;
    public int bfX = 0, bfZ = 0, bfY = -40, bfSX = 48, bfSZ = 48, bfFar = 5, bfTol = 600;
    // Đào hầm thẳng
    public int tnMode = 0, tnDir = 0, tnLen = 0;     // tnMode 0 cúp thường / 1 amethyst 3x3; tnDir 0 theo hướng nhìn, 1 B, 2 N, 3 Đ, 4 T, 5 xuống bậc thang
    public boolean tnFloor = true, tnSafe = true;
    public int bfMaxY = 8;                            // BaseFinder: chỉ tính hang từ tầng deepslate (Y <= bfMaxY) trở xuống
    public boolean spawnerNatural = false;            // Spawner ESP: hiện cả lồng quái tự nhiên (dungeon / mineshaft / trial)
    // FreeDig (freecam chọn vùng đào)
    public int fdSpeed = 14, fdRange = 96;
    public int uiTrans = 0;                         // menu trong suốt (0-90 %)
}
