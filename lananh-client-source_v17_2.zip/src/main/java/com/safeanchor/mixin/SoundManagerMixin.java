package com.safeanchor.mixin;

import com.safeanchor.KeySound;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Thay tiếng của mọi thứ trong game bằng tiếng bàn phím (xem KeySound.replace). */
@Mixin(SoundManager.class)
public class SoundManagerMixin {
    @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void lananh$replace(SoundInstance sound, CallbackInfo ci) {
        if (KeySound.replace(sound)) ci.cancel();
    }
}
